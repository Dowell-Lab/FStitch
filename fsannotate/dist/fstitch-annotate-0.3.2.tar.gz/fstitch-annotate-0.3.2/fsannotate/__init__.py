import fsannotate.bidir as bd
import fsannotate.expand as e

def bidir():
    bd.main()
    
def expand():
    e.main()    